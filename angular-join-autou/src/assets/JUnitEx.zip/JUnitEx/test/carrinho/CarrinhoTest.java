package carrinho;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotSame;
import static junit.framework.Assert.assertTrue;
import static junit.framework.Assert.fail;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.CoreMatchers.*;
import org.junit.Before;
import org.junit.Test;
import produto.Produto;
import produto.ProdutoNaoEncontradoException;



public class CarrinhoTest {
	
    Carrinho cliente1;
    
    Produto livro;
    Produto refri;
    Produto cerveja;
    Produto brinquedo;
    
    	@Before
	public void inicializa() {
            livro = new Produto("Introducao ao Teste de Software", 100.00);
            refri = new Produto("Coca", 5.00);
            cerveja = new Produto("Bud", 7.00);
            brinquedo = new Produto("funko", 50);
            
            cliente1 = new Carrinho();
            cliente1.addItem(livro);
            cliente1.addItem(refri);
            cliente1.addItem(cerveja);
	}
        
        @Test
        public void testQuantidade(){
            assertEquals(3, cliente1.getQtdeItems());
        }
        
        @Test
        public void testRemove(){
            try{
                cliente1.removeItem(livro);
            }catch(ProdutoNaoEncontradoException error){
                fail("Produto nao encontrado");
            }
            assertEquals(2, cliente1.getQtdeItems());
        }
        
        @Test
        public void testAdd(){
            cliente1.addItem(brinquedo);
            assertEquals(4, cliente1.getQtdeItems());
        }
        
        @Test
        public void testTotal(){
            assertEquals(112.0, cliente1.getValorTotal());
        }
        
        @Test
        public void testEsvaziar(){
            cliente1.esvazia();
            assertEquals(0, cliente1.getQtdeItems());
        }
    
    
    
}
